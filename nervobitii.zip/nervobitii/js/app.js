(() => {
  const TOTAL_SEATS = 300;
  const MAX_REC = 180;
  const MASKS = ["Anonim", "Deputat", "Dac", "Bufon", "Marmură"];
  const BODIES = ["Om", "Alien", "Dac", "Spartan", "Rege", "Om de paie"];
  const PRIVACY = ["Invizibil", "Față+mască", "Față reală"];

  const seedDeputies = [
    { loc: 7, nume: "Andrei Vasilescu", oras: "Iași", gift: "trandafiri", propunere: "Legea drumurilor județene" },
    { loc: 18, nume: "Elena Marin", oras: "București", gift: "gogoasa", propunere: "Taxe pentru tineri" },
    { loc: 102, nume: "Mihai Stan", oras: "Timișoara", gift: "gogoasa", propunere: "Spitale fără cozi" },
    { loc: 201, nume: "Ioana Radu", oras: "Constanța", gift: "palarie", propunere: "Protecția litoralului" },
    { loc: 299, nume: "Gheorghe Popa", oras: "Brașov", gift: "palarie", propunere: "Pădurile din Carpați" }
  ];

  const giftRank = { trandafiri: 3, gogoasa: 2, palarie: 1 };

  const state = {
    seats: {},
    me: JSON.parse(localStorage.getItem("nervo_me") || "null"),
    clips: JSON.parse(localStorage.getItem("nervo_clips") || "null") || [
      { titlu: "Legea drumurilor județene", autor: "Andrei Vasilescu", inimi: 12, voturi: 8, don: 3 },
      { titlu: "Taxe pentru tineri", autor: "Elena Marin", inimi: 9, voturi: 5, don: 1 }
    ],
    mask: 0, body: 0, privacy: 0,
    mic: true, removeBg: false,
    overlayImg: null,
    recording: false,
    recStart: 0,
    mediaStream: null,
    recorder: null,
    chunks: [],
    blobUrl: null,
    selectedSeat: null
  };

  seedDeputies.forEach((d) => { state.seats[d.loc] = d; });
  const savedSeats = JSON.parse(localStorage.getItem("nervo_seats") || "{}");
  Object.assign(state.seats, savedSeats);

  const $ = (id) => document.getElementById(id);
  const toast = (t) => {
    const el = $("toast");
    el.textContent = t;
    el.style.display = "block";
    setTimeout(() => (el.style.display = "none"), 2200);
  };

  function go(id) {
    document.querySelectorAll(".screen").forEach((s) => s.classList.remove("active"));
    document.getElementById(id).classList.add("active");
    document.querySelectorAll(".nav button").forEach((b) => {
      b.classList.toggle("active", b.dataset.go === id);
    });
    if (id === "studio") startCam();
    if (id === "seats") renderSeats();
    if (id === "feed") renderFeed();
  }

  document.querySelectorAll("[data-go]").forEach((b) => {
    b.addEventListener("click", () => go(b.dataset.go));
  });

  function save() {
    localStorage.setItem("nervo_me", JSON.stringify(state.me));
    localStorage.setItem("nervo_seats", JSON.stringify(
      Object.fromEntries(Object.entries(state.seats).filter(([k]) => !seedDeputies.find((d) => String(d.loc) === String(k))))
    ));
    localStorage.setItem("nervo_clips", JSON.stringify(state.clips));
    $("userChip").textContent = state.me ? `${state.me.nume} · loc ${state.me.loc}` : "vizitator";
  }
  save();

  function renderSeats() {
    const grid = $("seatGrid");
    grid.innerHTML = "";
    for (let i = 1; i <= TOTAL_SEATS; i++) {
      const b = document.createElement("button");
      b.className = "seat" + (state.seats[i] ? " ocupat" : "");
      if (state.me && state.me.loc === i) b.classList.add("me");
      b.title = state.seats[i]
        ? `#${i} ${state.seats[i].nume} · ${state.seats[i].oras}`
        : `#${i} liber`;
      b.addEventListener("click", () => selectSeat(i));
      grid.appendChild(b);
    }
    const q = Object.values(state.seats)
      .sort((a, b) => (giftRank[b.gift] || 0) - (giftRank[a.gift] || 0) || a.loc - b.loc);
    $("queueList").innerHTML = q
      .map((p, i) => `<div class="queue-item"><span>${i + 1}. ${p.nume} · ${p.oras}</span><span>${giftLabel(p.gift)}</span></div>`)
      .join("");
  }

  function giftLabel(g) {
    return { trandafiri: "🌹 x10", gogoasa: "🍩", palarie: "🎩" }[g] || g;
  }

  function selectSeat(i) {
    if (state.seats[i]) {
      const d = state.seats[i];
      toast(`Loc ${i} ocupat: ${d.nume}, ${d.oras}`);
      $("reserveBox").style.display = "none";
      return;
    }
    state.selectedSeat = i;
    $("selSeat").textContent = i;
    $("reserveBox").style.display = "block";
  }

  $("btnReserve").addEventListener("click", () => {
    const nume = $("nume").value.trim();
    const oras = $("oras").value.trim();
    if (!nume || !oras) return toast("Completează nume și oraș");
    if (state.me && state.seats[state.me.loc]) {
      return toast("Ai deja un loc. Un loc per cont.");
    }
    const loc = state.selectedSeat;
    state.seats[loc] = { loc, nume, oras, gift: "palarie", propunere: "" };
    state.me = { loc, nume, oras };
    save();
    renderSeats();
    toast("Loc rezervat cu Pălăria");
    $("reserveBox").style.display = "none";
  });

  document.querySelectorAll(".gift").forEach((g) => {
    g.addEventListener("click", () => giveGift(g.dataset.gift));
  });

  function giveGift(type) {
    if (!state.me) return toast("Rezervă întâi un loc");
    state.seats[state.me.loc].gift = type;
    if (type === "trandafiri") toast("Prioritate maximă la prezidiu");
    else if (type === "gogoasa") toast("Ai urcat în coadă");
    else toast("Loc confirmat");
    save();
    renderSeats();
  }

  const cam = $("cam");
  const canvas = $("stage");
  const ctx = canvas.getContext("2d");
  const sala = new Image();
  sala.src = "assets/sala.jpg";
  let raf = 0;

  async function startCam() {
    if (state.mediaStream) return draw();
    try {
      state.mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 720 }, height: { ideal: 1280 } },
        audio: true
      });
      cam.srcObject = state.mediaStream;
      await cam.play();
      draw();
    } catch (e) {
      toast("Permite camera și microfonul");
    }
  }

  function draw() {
    cancelAnimationFrame(raf);
    const w = canvas.clientWidth || 360;
    const h = canvas.clientHeight || 640;
    if (canvas.width !== w) { canvas.width = w; canvas.height = h; }

    if (sala.complete) ctx.drawImage(sala, 0, 0, w, h);
    else { ctx.fillStyle = "#1a120a"; ctx.fillRect(0, 0, w, h); }

    const cw = w * 0.42, ch = h * 0.38;
    const cx = (w - cw) / 2, cy = h * 0.33;

    if (cam.readyState >= 2) {
      ctx.save();
      if (state.removeBg || state.privacy !== 2) {
        ctx.beginPath();
        ctx.ellipse(cx + cw / 2, cy + ch / 2, cw / 2, ch / 2, 0, 0, Math.PI * 2);
        ctx.clip();
      } else {
        ctx.globalAlpha = 0.35;
      }
      ctx.translate(w, 0);
      ctx.scale(-1, 1);
      const sx = w - cx - cw;
      ctx.drawImage(cam, sx, cy, cw, ch);
      ctx.restore();
    }

    drawBodyHint(ctx, cx, cy, cw, ch);
    if (state.privacy !== 2) drawMask(ctx, cx + cw / 2, cy + ch * 0.32, cw * 0.34);
    if (state.overlayImg) {
      const s = cw * 0.28;
      ctx.drawImage(state.overlayImg, cx + cw / 2 - s / 2, cy + 8, s, s);
    }

    ctx.fillStyle = "rgba(0,0,0,.45)";
    ctx.fillRect(12, 12, 150, 22);
    ctx.fillStyle = "#f0e0a8";
    ctx.font = "12px Georgia";
    ctx.fillText("NERVOBIȚII", 20, 27);

    raf = requestAnimationFrame(draw);
  }

  function drawMask(ctx, x, y, r) {
    ctx.save();
    ctx.translate(x, y);
    const kind = MASKS[state.mask];
    if (kind === "Anonim") {
      ctx.fillStyle = "#c9a44a";
      ctx.beginPath(); ctx.ellipse(0, 0, r, r * 1.15, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#1a120a";
      ctx.beginPath(); ctx.ellipse(-r * 0.35, -r * 0.1, r * 0.16, r * 0.12, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(r * 0.35, -r * 0.1, r * 0.16, r * 0.12, 0, 0, Math.PI * 2); ctx.fill();
    } else if (kind === "Deputat") {
      ctx.fillStyle = "#e8c9a0";
      ctx.beginPath(); ctx.ellipse(0, 0, r * 0.95, r * 1.1, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#222"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(-r * 0.32, 0, r * 0.22, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(r * 0.32, 0, r * 0.22, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-r * 0.1, 0); ctx.lineTo(r * 0.1, 0); ctx.stroke();
    } else if (kind === "Dac") {
      ctx.fillStyle = "#8a7350";
      ctx.beginPath(); ctx.moveTo(0, -r * 1.3); ctx.lineTo(r, r * 0.4); ctx.lineTo(-r, r * 0.4); ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#1a120a";
      ctx.fillRect(-r * 0.45, -r * 0.15, r * 0.3, r * 0.12);
      ctx.fillRect(r * 0.15, -r * 0.15, r * 0.3, r * 0.12);
    } else if (kind === "Bufon") {
      ctx.fillStyle = "#d4c4a0";
      ctx.beginPath(); ctx.ellipse(0, 0, r, r * 1.05, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#7a1f2b";
      ctx.beginPath(); ctx.moveTo(-r, -r * 0.2); ctx.lineTo(-r * 1.2, -r * 1.1); ctx.lineTo(-r * 0.2, -r * 0.6); ctx.fill();
      ctx.beginPath(); ctx.moveTo(r, -r * 0.2); ctx.lineTo(r * 1.2, -r * 1.1); ctx.lineTo(r * 0.2, -r * 0.6); ctx.fill();
    } else {
      ctx.fillStyle = "#e8e4dc";
      ctx.beginPath(); ctx.ellipse(0, 0, r, r * 1.2, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#b8b2a8"; ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawBodyHint(ctx, x, y, w, h) {
    ctx.save();
    ctx.globalAlpha = 0.25;
    ctx.strokeStyle = "#d4b56a";
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#f0e0a8";
    ctx.font = "11px Georgia";
    ctx.fillText(BODIES[state.body] + " · " + PRIVACY[state.privacy], x, y - 6);
    ctx.restore();
  }

  $("btnMic").addEventListener("click", () => {
    state.mic = !state.mic;
    if (state.mediaStream) {
      state.mediaStream.getAudioTracks().forEach((t) => (t.enabled = state.mic));
    }
    $("btnMic").textContent = state.mic ? "🎙 Microfon ON" : "🎙 Microfon OFF";
  });

  $("btnBg").addEventListener("click", () => {
    state.removeBg = !state.removeBg;
    $("btnBg").textContent = state.removeBg ? "AI Remove BG ON" : "AI Remove BG OFF";
    toast(state.removeBg ? "Ești decupat pe tribună (simulare)" : "Remove BG oprit");
  });

  $("btnMask").addEventListener("click", () => {
    state.mask = (state.mask + 1) % MASKS.length;
    $("btnMask").textContent = "Masca: " + MASKS[state.mask];
  });
  $("btnBody").addEventListener("click", () => {
    state.body = (state.body + 1) % BODIES.length;
    $("btnBody").textContent = "Corp: " + BODIES[state.body];
  });
  $("btnPrivacy").addEventListener("click", () => {
    state.privacy = (state.privacy + 1) % PRIVACY.length;
    $("btnPrivacy").textContent = "Privacy: " + PRIVACY[state.privacy];
  });

  $("btnUpload").addEventListener("click", () => $("fileMask").click());
  $("fileMask").addEventListener("change", (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const img = new Image();
    img.onload = () => { state.overlayImg = img; toast("Masca încărcată"); };
    img.src = URL.createObjectURL(f);
  });

  $("btnAiMask").addEventListener("click", () => {
    const p = prompt("Descrie masca (ex: mască de corb aurie)");
    if (!p) return;
    state.mask = 0;
    toast("AI mască (local): " + p + " → Anonim stilizat. În producție apelează un API de imagine.");
  });

  $("btnLink").addEventListener("click", () => {
    const url = prompt("Link GIF / PNG");
    if (!url) return;
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => { state.overlayImg = img; toast("Sticker din link"); };
    img.onerror = () => toast("Link blocat de CORS. Folosește Upload.");
    img.src = url;
  });

  function applause() {
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    for (let i = 0; i < 18; i++) {
      const o = ac.createOscillator();
      const g = ac.createGain();
      o.type = "square";
      o.frequency.value = 400 + Math.random() * 800;
      g.gain.value = 0.02;
      o.connect(g); g.connect(ac.destination);
      const t = ac.currentTime + Math.random() * 0.9;
      o.start(t); o.stop(t + 0.08);
    }
  }

  let tick = null;
  $("recBtn").addEventListener("click", async () => {
    if (state.recording) return stopRec();
    if (!state.mic) return toast("Pornește microfonul");
    if (!state.mediaStream) await startCam();
    let n = 3;
    $("count").textContent = n;
    const iv = setInterval(() => {
      n -= 1;
      $("count").textContent = n > 0 ? n : n === 0 ? "1" : "";
      if (n <= 0) {
        clearInterval(iv);
        $("count").textContent = "";
        beginRec();
      }
    }, 700);
  });

  function beginRec() {
    const stream = canvas.captureStream(25);
    const audioTracks = state.mediaStream.getAudioTracks();
    audioTracks.forEach((t) => stream.addTrack(t));
    const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus")
      ? "video/webm;codecs=vp9,opus"
      : "video/webm";
    state.chunks = [];
    try {
      state.recorder = new MediaRecorder(stream, { mimeType: mime });
    } catch {
      state.recorder = new MediaRecorder(stream);
    }
    state.recorder.ondataavailable = (e) => { if (e.data.size) state.chunks.push(e.data); };
    state.recorder.onstop = onRecStop;
    state.recorder.start(200);
    state.recording = true;
    state.recStart = Date.now();
    $("recBtn").classList.add("on");
    tick = setInterval(updateTimer, 200);
  }

  function updateTimer() {
    const s = Math.min(MAX_REC, Math.floor((Date.now() - state.recStart) / 1000));
    const mm = String(Math.floor(s / 60)).padStart(2, "0");
    const ss = String(s % 60).padStart(2, "0");
    $("recTimer").textContent = `${mm}:${ss} / 03:00`;
    if (s >= MAX_REC) stopRec();
  }

  function stopRec() {
    if (!state.recording) return;
    state.recording = false;
    $("recBtn").classList.remove("on");
    clearInterval(tick);
    state.recorder.stop();
    applause();
    toast("Aplauze. Preview.");
  }

  function onRecStop() {
    const blob = new Blob(state.chunks, { type: "video/webm" });
    if (state.blobUrl) URL.revokeObjectURL(state.blobUrl);
    state.blobUrl = URL.createObjectURL(blob);
    $("previewVid").src = state.blobUrl;
    go("preview");
  }

  $("btnDelete").addEventListener("click", () => {
    state.blobUrl = null;
    $("previewVid").src = "";
    toast("Șters");
    go("studio");
  });

  $("btnPublish").addEventListener("click", () => {
    const titlu = $("titlu").value.trim() || "Fără titlu";
    state.clips.unshift({
      titlu,
      autor: state.me ? state.me.nume : "Anonim",
      url: state.blobUrl,
      inimi: 0,
      voturi: 0,
      don: 0
    });
    if (state.me && state.seats[state.me.loc]) state.seats[state.me.loc].propunere = titlu;
    save();
    toast("Publicat. Logo NERVOBIȚII e pe clip.");
    renderFeed();
    go("feed");
  });

  function renderFeed() {
    $("feedList").innerHTML = state.clips.map((c, i) => `
      <div class="card">
        <strong>${c.titlu}</strong>
        <div class="muted">${c.autor}</div>
        ${c.url ? `<video src="${c.url}" controls style="width:100%;margin-top:8px;border-radius:8px"></video>` : ""}
        <div class="actions">
          <button data-act="heart" data-i="${i}">❤ ${c.inimi}</button>
          <button data-act="vote" data-i="${i}">Vot ${c.voturi}</button>
          <button data-act="don" data-i="${i}">🍩 ${c.don}</button>
        </div>
        <div class="actions">
          <button data-share="ig">Instagram</button>
          <button data-share="fb">Facebook</button>
          <button data-share="tt">TikTok</button>
        </div>
      </div>
    `).join("");
    $("feedList").onclick = (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      if (b.dataset.share) {
        const text = encodeURIComponent("Nervobiții — tribuna virtuală (pamflet)");
        const url = encodeURIComponent(location.href);
        const map = {
          ig: `https://www.instagram.com/`,
          fb: `https://www.facebook.com/sharer/sharer.php?u=${url}`,
          tt: `https://www.tiktok.com/upload?lang=en`
        };
        window.open(map[b.dataset.share], "_blank");
        return;
      }
      const i = +b.dataset.i;
      if (b.dataset.act === "heart") state.clips[i].inimi++;
      if (b.dataset.act === "vote") state.clips[i].voturi++;
      if (b.dataset.act === "don") state.clips[i].don++;
      save();
      renderFeed();
    };
  }

  renderSeats();
  renderFeed();
})();
