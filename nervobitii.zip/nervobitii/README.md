# Nervobiții

Aplicație-pamflet: tribună virtuală inspirată de o sală de parlament.  
**Nu este Camera Deputaților și nu reprezintă o instituție a statului.**

## Ce merge în prototip

- 300 de locuri (verde liber / roșu ocupat)
- 5 useri demo deja așezați
- Rezervare loc cu **Pălăria** + nume + oraș (un loc per cont)
- Cadouri: 🎩 pălărie, 🍩 gogoașă, 🌹 10 trandafiri → ordinea la prezidiu
- Cameră + microfon (cerute la prima filmare)
- Countdown 3-2-1, record video+audio, stop oricând, max 3 minute
- Aplauze scurte la stop
- Preview: Publică sau Șterge + titlu
- Logo **NERVOBIȚII** pe scenă
- 5 măști preset, 6 corpuri, 3 moduri privacy
- Upload mască din telefon/PC
- Link GIF/PNG (poate fi blocat de CORS → folosește Upload)
- AI mască: prompt local (în producție se leagă de un API de imagine)
- Remove BG: simulare (te decupează pe tribună peste sala generată)
- Feed: inimioară, vot, donație, share IG/FB/TikTok
- Datele rămân în `localStorage` în browser

## Cum rulezi

Camera merge doar pe **HTTPS** sau `localhost`.

```bash
cd nervobitii
python3 -m http.server 8080
```

Deschide `http://localhost:8080`

## GitHub Pages

1. Creează un repo nou
2. Încarcă tot conținutul folderului `nervobitii` (index.html în rădăcină)
3. Settings → Pages → Deploy from branch `main`

## Ce lipsește intenționat (următorul pas)

- Plăți reale
- Remove-bg ML (@imgly/background-removal)
- Generare AI reală de mască
- Conturi / backend
- Intro 30s ca track separat
- Live

## Stack

HTML + CSS + JS, MediaRecorder, Canvas, fără framework.
